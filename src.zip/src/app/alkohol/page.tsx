const Alcohol = () => {
	return <div>Alcohol</div>;
};

export default Alcohol;
